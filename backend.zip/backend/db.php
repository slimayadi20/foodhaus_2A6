<?php

	$dsn = "mysql:host=localhost;dbname=evenement";

	try {
		$pdo = new PDO($dsn, 'root', '');
	}
	catch(PDOException $e) {
		echo $e->getMessage();
	}

?>